﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using CourseAttendance.Enums;
using CourseAttendance.Model.Users;

namespace CourseAttendance.Model
{
    public class Attendance
	{
        [Key]
		public int Id { get; set; }
		[ForeignKey("Course")]
		public int CourseId { get; set; }
		[ForeignKey("Student")]
		public int StudentId { get; set; }
		public DateTime AttendanceDate { get; set; }
		public DateTime? SignInTime { get; set; }
		public DateTime? SignOutTime { get; set; }
		public AttendanceStatus Status { get; set; }
		public PerformanceLevel Performance { get; set; }
		public string Remark { get; set; }
		public CheckMethod CheckMethod { get; set; }
		public string Location { get; set; }
		public DateTime CreatedAt { get; set; } = DateTime.Now;
		public DateTime UpdatedAt { get; set; } = DateTime.Now;

		public virtual Course Course { get; set; }
		public virtual Student Student { get; set; }
	}
}
