﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace CourseAttendance.Model.Users
{
    public class Counselor
    {
        [Key]
        [ForeignKey("User")]
        public int UserId { get; set; } // 外键，作为主键

        public virtual User User { get; set; } // 对应的用户信息

        public virtual ICollection<Grade> Grades { get; set; } // 辅导员负责的班级
    }
}
